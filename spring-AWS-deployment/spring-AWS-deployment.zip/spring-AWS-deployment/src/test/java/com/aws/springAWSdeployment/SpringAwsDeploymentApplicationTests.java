package com.aws.springAWSdeployment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringAwsDeploymentApplicationTests {

	@Test
	void contextLoads() {
	}

}
