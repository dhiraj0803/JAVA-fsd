package Collections;
import java.util.*;

public class collection{

	public static void main(String[] args) {
		//creating arraylist
		
		System.out.println("ArrayList");
		ArrayList<String> colleges=new ArrayList<String>();   
	      colleges.add("IIT");//
	      colleges.add("NIT");
	      colleges.add("IIT");
	      System.out.println(colleges);  
		
		//creating vector
	      
	      System.out.println("\n");
	      System.out.println("Vector");
	      Vector<Integer> vec = new Vector<Integer>();
	      vec.addElement(15); 
	      vec.addElement(30); 
	      System.out.println(vec);
		
		//creating linked_list
	      
	      System.out.println("\n");
	      System.out.println("LinkedList");
	      LinkedList<String> names=new LinkedList<String>();  
	      names.add("Alex");  
	      names.add("John");  	      
	      Iterator<String> itr=names.iterator();  
	      while(itr.hasNext()){  
		       System.out.println(itr.next());
		       
		       //creating linked_hashset
		       
		       System.out.println("LinkedHashSet");
		       LinkedHashSet<Integer> set2=new LinkedHashSet<Integer>();  
		       set2.add(11);  
		       set2.add(13);  
		       set2.add(12);
		       set2.add(14);	       
		       System.out.println(set2);
	      	} 
	      
	      System.out.println("Stack");
	      Stack<String> things=new Stack<String>();
	      things.push("pen");
	      things.push("paper");
	      things.pop();
	      things.push("bags");
	      things.pop();
	      things.push("Dhiraj");
	      
	      Iterator<String> i = things.iterator();
	      while(i.hasNext())
	    	  System.out.println(i.next());
	      
	      
	      }  
	}

