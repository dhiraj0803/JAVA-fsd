package INNER_CLASS;

class outer_class {
	   private int num = 72; 
	   class inner_class {
	      public int getNum() {
	         System.out.println("This is the getnum method of the inner class:");
	         return num;
	      }
	   }
	}
	   
public class inner {

	  public static void main(String args[]) {
	      outer_class outer = new outer_class();
	      outer_class.inner_class inner = outer.new inner_class();
	      System.out.println(inner.getNum());
	   }
	}
