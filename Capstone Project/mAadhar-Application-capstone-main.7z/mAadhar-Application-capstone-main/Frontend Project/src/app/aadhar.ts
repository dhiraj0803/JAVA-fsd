export class Aadhar {
    constructor(public cid:number,
        public cname:String,
        public dob:String,
        public address:String,
        public emailid:String,
        public gender:String,
        public number:String){}
}
