import { Aadhar } from './aadhar';

describe('Aadhar', () => {
  it('should create an instance', () => {
    expect(new Aadhar()).toBeTruthy();
  });
});
