package file_handling;
import java.io.*;
public class file_raw {
	 public static void main(String[] args) {
		 
	        String file = "file 1.txt";

	        writeToFile(file, "Hello, Dhiraj here how are you!");

	        String content = readFromFile(file);
	        
	        System.out.println("File contains :  " + content);
	        
	        appendToFile(file, "\nThis is an appended line.");

	        content = readFromFile(file);
	        
	        System.out.print("Updated file content: " + content);
	    }

	    // Method to write content to a file
	    public static void writeToFile(String file, String content) {
	        try (FileWriter writer = new FileWriter(file)) {
	            writer.write(content);
	            writer.close();
	        } catch (IOException e) {
	        	System.out.println("Exception is " + e);
	        }
	    }

	    // Method to read content from a file
	    public static String readFromFile(String file) {
	        StringBuilder content = new StringBuilder();
	        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
	            String line;
	            while ((line = reader.readLine()) != null) {
	                content.append(line).append("\n");
	            }
	        } catch (IOException e) {
	        	System.out.println("Exception is " + e);
	        }
	        return content.toString();
	    }

	    // Method to append content to a file
	    public static void appendToFile(String file, String content) {
	        try (FileWriter writer = new FileWriter(file, true)) {
	            writer.write(content);
	            writer.close();
	        } catch (IOException e) {
	            System.out.println("Exception is " + e);
	        }
	    }

	

}



