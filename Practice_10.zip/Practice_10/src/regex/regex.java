package regex;
import java.util.regex.*;
import java.util.*;

public class regex {

public static void main(String[] args) {
		ArrayList<String> email_list=new ArrayList<String>(); // WITH THE HELP COLLECTIONS CREATING THE ARRAY LIST
		
		email_list.add("y1dhiraj@yahoo.com");
		email_list.add("sumeet@yahoo.com");
		email_list.add("1dhiraj@.com");
		email_list.add("amit4433*&%#yahoo.com");
		email_list.add("@mail.com");
		email_list.add("y1dhiraj@yahoo.co.in");
		email_list.add("y1dhiraj@yahoo.co.en");
		email_list.add("y1dhiraj@yahoo.com.");
	

		Scanner sc=new Scanner(System.in);
		System.out.print("Enter your email adderess : ");
		String mail=sc.next();
		System.out.println('\n');

		if(emailvalidator(mail))
			System.out.println("Your email is valid\n");
		else
			System.out.println("Entered email address is invalid\n");

		sc.close();

	}



	//DEFINING THE METHOD FOR EMAILVALIDATOR
	public static boolean emailvalidator(String mail)
	{
		String regular_expression="^[A-Za-z0-9+_.-]+@(.+)[a-zA-Z]$";   //REGULAR EXPRESSION TO MATCH THE PATTERN OF VALID EMAIL ID

		Pattern p=Pattern.compile(regular_expression);  //COMPILING THE REGULAR_EXPRESSION

		Matcher match=p.matcher(mail);  //CREATING THE MATCHER

		return match.matches();  //IF EMAIL ID MATCHES THE PATTERN OF REGULAR EXPRESSION IT RETURNS TRUE AND IF NOT IT RETURNS FALSE  
		
	}

}
