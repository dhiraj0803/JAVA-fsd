package lngst_incrsng_sbsqnc;
import java.util.*;



public class longest_increaing_subsequence {
	
    public static int LIS(int[] list,int l) 
       {
        if (list == null || l == 0) {
            return 0;
        }

        int[] dp = new int[l];
        Arrays.fill(dp, 1);

        for (int i = 1; i < l; i++) {
            for (int j = 0; j < i; j++) {
                if (list[i] > list[j]) {
                    dp[i] = Math.max(dp[i], dp[j] + 1);
                }
            }
        }

        int max_len = 0;
        for (int i : dp) {
            if (i > max_len) {
                max_len = i;
            }
        }

        return max_len;
    }

    public static void main(String[] args) {
        
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the number of elements in the list");
        int l=sc.nextInt();
        int[] list=new int[l];
        System.out.println("Enter the elements in the list");
        for(int i=0;i<l;i++)
        	list[i]=sc.nextInt();
        int max = LIS(list,l);
        System.out.println("length of longest increasing subsequence is  " + max);
    }
}
