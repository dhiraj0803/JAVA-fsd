package arrays_operation;

public class arrays {

	public static void main(String[] args) {
		int arr[]= {4,1,2,4,7,5,4};
		int l=arr.length;
		int sum=0;
		for(int i:arr)
			sum+=i;
		System.out.println("Sum of elements in array is : " + sum)
		;
		
		int mat[][]= {{5,4,21,6,7},{1,2,4,3,7}};
		
		for(int i=0;i<mat.length;i++)
		{
			for(int j=0;j<mat[0].length;j++){
				
				System.out.println("element at index " + i + j + " : " + mat[i][j]);
			}
		}
		
	}

}
