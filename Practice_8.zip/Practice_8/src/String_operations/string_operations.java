package String_operations;

public class string_operations {

	public static void main(String[] args) {
		String s1="Dhiraj";
		String s2="DHIraJ";
		System.out.println(s1.charAt(1));
		System.out.println(s1.compareTo(s2));
		System.out.println(s1.compareToIgnoreCase(s2));
		String s3="Yadav";
		String s4=s1.concat(s3);
		System.out.println(s4);
		StringBuffer s=new StringBuffer("Welcome to my home");
		s.append("It's all yours");
		System.out.println(s);
		StringBuffer sb=new StringBuffer("Hello");
		sb.replace(0, 2, "hEl");
		System.out.println(sb);
		sb.delete(0, 1);
		System.out.println(sb);
		StringBuilder string_build=new StringBuilder("Happy");
		string_build.append("Diwali");
		System.out.println(string_build);
		string_build.reverse();
		System.out.println(string_build);

	}

}
