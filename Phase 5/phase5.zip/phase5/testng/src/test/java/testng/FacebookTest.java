package testng;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.*;
import org.testng.annotations.AfterMethod;

public class FacebookTest {
	
	WebDriver driver=null;
	
	WebDriverWait wait=null;
  @Test
  public void welcome() {
	  
	  System.out.println("Welcome to Automated Testing");
	  
  }
  @BeforeMethod
  public void beforeMethod() {
	  System.out.println("Before Method");
	  System.setProperty("webdriver.chrome.driver","C:\\Users\\Admin\\Downloads\\New folder\\chromedriver-win64\\chromedriver.exe" );
	  driver =new ChromeDriver();
	  driver.get("https://www.facebook.com/");
	  
	  wait=new WebDriverWait(driver, 10);
	  
	  WebElement email=driver.findElement(By.id("email"));
	  email.sendKeys("y1dhiraj@gmail.com");
	  
	  WebElement pass=driver.findElement(By.id("pass"));
	  pass.sendKeys("dhiraj@1997");
	  
	  
	  
  }

  @AfterMethod
  public void afterMethod() {
	  
	  System.out.println("After Method");
	  driver=null;
	  
  }

}