package com.flipkart;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class FlipkartTest {

	WebDriver driver;
	WebDriverWait wait;

	@BeforeTest

	public void setUp() {


		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Admin\\Downloads\\New folder\\chromedriver-win64\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		wait = new WebDriverWait(driver, Duration.ofSeconds(10));
	}

	@Test
	public void testLazyLoadingFeature() throws InterruptedException {
		
		driver.get("https://www.flipkart.com/");

		long startTime = System.currentTimeMillis();
		
		WebElement hrefLink = driver.findElement(By.cssSelector("a[href='https://www.flipkart.com/mobile-phones-store?fm=neo%2Fmerchandising&iid=M_9d0122f2-532e-4cb8-812b-667bc88940d5_1_372UD5BXDFYS_MC.ZRQ4DKH28K8J&otracker=hp_rich_navigation_2_1.navigationCard.RICH_NAVIGATION_Mobiles_ZRQ4DKH28K8J&otracker1=hp_rich_navigation_PINNED_neo%2Fmerchandising_NA_NAV_EXPANDABLE_navigationCard_cc_2_L0_view-all&cid=ZRQ4DKH28K8J']"));

		hrefLink.click();
		
		Thread.sleep(10000);
		
		WebElement searchBox = driver.findElement(By.name("q"));
		
		searchBox.sendKeys("iPhone 13");
		searchBox.submit();

		slowScrollDown();

		long endTime = System.currentTimeMillis();
		long pageLoadTime = endTime - startTime;
		System.out.println("Page Load Time: " + pageLoadTime + " milliseconds");
	}

	private void slowScrollDown() {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		Actions actions = new Actions(driver);

		for (int i = 0; i < 15; i++) 
		{
			actions.sendKeys(" ").build().perform();
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"container\"]/div/div[3]/div[1]/div[2]/div[2]")));

			try 
			{
				Thread.sleep(1000);
			} 
			catch (InterruptedException e) 
			{
				e.printStackTrace();
			}
		}
	}

	@AfterTest
	public void tearDown() 
	{
		driver.quit();
		
	}
}
