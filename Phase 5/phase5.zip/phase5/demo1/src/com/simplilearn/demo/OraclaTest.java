package com.simplilearn.demo;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class OraclaTest {

	public static void main(String[] args) throws InterruptedException {
		 System.setProperty("webdriver.chrome.driver", "C:\\Users\\Admin\\Downloads\\New folder\\chromedriver-win64\\chromedriver.exe");
		
		WebDriver driver= new ChromeDriver();
		
		driver.get("https://profile.oracle.com/myprofile/account/create-account.jspx");
		
		Thread.sleep(5000);
		
		WebElement email=driver.findElement(By.xpath("//*[@id=\"sView1:r1:0:email::content\"]"));
		
		email.sendKeys("dhiraj2000@mail.com");
		
		WebElement password=driver.findElement(By.xpath("//*[@id=\"sView1:r1:0:password::content\"]"));
		password.sendKeys("Dhiraj@1997");
		
		WebElement retype=driver.findElement(By.id("sView1:r1:0:retypePassword::content"));
		retype.sendKeys("Dhiraj@1997");
		
		WebElement country=driver.findElement(By.xpath("//*[@id=\"sView1:r1:0:country::content\"]"));
		country.sendKeys("India");
		
		WebElement fname=driver.findElement(By.id("sView1:r1:0:firstName::content"));
		fname.sendKeys("Dhiraj");
		
		WebElement lname=driver.findElement(By.id("sView1:r1:0:lastName::content"));
		lname.sendKeys("Yadav");
		
		WebElement jobTitle=driver.findElement(By.id("sView1:r1:0:jobTitle::content"));
		jobTitle.sendKeys("Associate Software Engineer");
		
		WebElement phone=driver.findElement(By.id("sView1:r1:0:workPhone::content"));
		phone.sendKeys("7271871078");
		
		WebElement companyName=driver.findElement(By.id("sView1:r1:0:companyName::content"));
		companyName.sendKeys("Mphasis");
		
		WebElement address=driver.findElement(By.id("sView1:r1:0:address1::content"));
		address.sendKeys("Opposite Bus depot kurla west LBS Road");
		
		WebElement city=driver.findElement(By.id("sView1:r1:0:city::content"));
		city.sendKeys("Mumbai");
		
		WebElement state=driver.findElement(By.id("sView1:r1:0:state::content"));
		state.sendKeys("Maharashtra");
		
		WebElement zipcode=driver.findElement(By.id("sView1:r1:0:postalCode::content"));
		zipcode.sendKeys("400070");
		
		
	}

}
