package com.simplilearn.demo;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class googleTest {
	public static void main(String[] args) {
		String path="C:\\Users\\Admin\\Downloads\\New folder\\chromedriver-win64\\chromedriver.exe";
		System.setProperty("webdriver.chrome.driver", path);
		String url="https://www.facebook.com/";
		
		WebDriver driver=new ChromeDriver();
		driver.get(url);
		
		WebElement email=driver.findElement(By.id("email"));
		
		System.out.println(email.getAttribute("placeholder"));
		email.sendKeys("dhi200hul1997@mail.com");
		
		WebElement password=driver.findElement(By.id("pass"));
		
		password.sendKeys("dhiraj1997");
		
		WebElement login=driver.findElement(By.name("login"));
		login.click();
		System.out.println("Chrome driver is working");
		

}
}
