package com.simplilearn.demo;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class WebdriverLocators {

	public static void main(String[] args) {
		String path="C:\\Users\\Admin\\Downloads\\New folder\\chromedriver-win64\\chromedriver.exe";
		System.setProperty("webdriver.chrome.driver", path);
		String url="https://www.facebook.com/";
		
		WebDriver driver=new ChromeDriver();
		driver.get(url);
		
		WebElement email_id=driver.findElement(By.id("email"));
		
		WebElement email_name=driver.findElement(By.name("email"));
		
		System.out.println("Email by id and name is:"+email_id.equals(email_name));
		
		WebElement link=driver.findElement(By.linkText("F]orgotten password?"));
		link.click();
		
		

	}

}
