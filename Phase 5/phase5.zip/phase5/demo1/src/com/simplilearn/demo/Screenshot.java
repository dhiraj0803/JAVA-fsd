package com.simplilearn.demo;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.io.FileHandler;


public class Screenshot {

	public static void main(String[] args) {
		 String path="C:\\Users\\Admin\\Downloads\\New folder\\chromedriver-win64\\chromedriver.exe";
		 System.setProperty("webdriver.chrome.driver", path);
		
		//initiate the driver
		WebDriver driver= new ChromeDriver();
		
		driver.get("https://www.shine.com/register/general/");

		
		TakesScreenshot screenshots=(TakesScreenshot) driver;
		File src=screenshots.getScreenshotAs(OutputType.FILE);
		
		try {
			FileHandler.copy(src, new File("C:\\Users\\Admin\\Downloads\\Pictures\\Screenshots\\mytest1.png"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
		
		driver.close();

	}

}
