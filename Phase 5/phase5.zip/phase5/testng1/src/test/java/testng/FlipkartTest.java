package testng;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class FlipkartTest {

    WebDriver driver;
    WebDriverWait wait;

    @BeforeTest
    @Parameters("browser")
    public void setUp(String browser) {
        if (browser.equalsIgnoreCase("chrome")) {
            System.setProperty("webdriver.chrome.driver", "path/to/chromedriver.exe");
            driver = new ChromeDriver();
        }

        driver.manage().window().maximize();
        wait = new WebDriverWait(driver, 10);
    }

    @Test
    public void testLazyLoadingFeature() throws InterruptedException {
        // Navigate to the Flipkart homepage
        driver.get("https://www.flipkart.com/");

        // Determine page load time
        long startTime = System.currentTimeMillis();

        // Perform the required actions
        // Search for a product
        WebElement searchBox = driver.findElement(By.name("q"));
        searchBox.sendKeys("iPhone 13");
        searchBox.submit();

        // Check images, slow scroll, refresh frequency, image download, and navigation
        slowScrollDown();
        // Additional checks can be added here based on your scenario

        // Calculate page load time
        long endTime = System.currentTimeMillis();
        long pageLoadTime = endTime - startTime;
        System.out.println("Page Load Time: " + pageLoadTime + " milliseconds");
    }

    private void slowScrollDown() {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        Actions actions = new Actions(driver);

        for (int i = 0; i < 5; i++) {
            actions.sendKeys(" ")
                   .build()
                   .perform();

            // Wait for images to load after each scroll
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("img.product-image")));
            
            // Simulate a delay to observe slow scrolling
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    @AfterTest
    public void tearDown() {
        driver.quit();
    }
}
}