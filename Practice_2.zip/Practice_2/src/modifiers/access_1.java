package modifiers;

public class access_1 {  
	public static void main(String[] args) {
    
    MyClass myObject = new MyClass();

    myObject.publicVar = 10;
    myObject.publicMethod();

    myObject.defaultMethod();
    myObject.protectedMethod();

}
}
class MyClass {

	public int publicVar;
	
	public void publicMethod() {
	    System.out.println("This is a public method. " + publicVar);
	}

	int defaultVar;
	
	void defaultMethod() {
	    System.out.println("This is a default method.");
	}

	private void privateMethod() {
	    System.out.println("This is a private method.");
	}
	
	// Protected member
	protected int protectedVar;
	
	protected void protectedMethod() {
	    System.out.println("This is a protected method.");
	}
	}


