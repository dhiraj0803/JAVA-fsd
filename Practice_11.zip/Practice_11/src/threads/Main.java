package threads;

class thread extends Thread {
    public void run() {
        
            System.out.println("Thread (extends Thread): ");
        
    }
}

class runnable implements Runnable {
    public void run() {
        
            System.out.println("Thread (implements Runnable): ");
    }
}

public class Main{
    public static void main(String[] args) {
    	
        thread thread1 = new thread();
        thread1.start();

        runnable runnable = new runnable();
        Thread thread2 = new Thread(runnable);
        thread2.start();
    }
}
