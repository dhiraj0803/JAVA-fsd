package Constructors;

public class constructors {
	public static void main(String[] args) {
		MultiCons  mc1 = new MultiCons();  // without parameter
		mc1.PrintVal();
		
		MultiCons  mc2 = new MultiCons(444,555);  // with parameters
		mc2.PrintVal();
	}
}


class MultiCons {
	private int x, y;
	
	public MultiCons()
	{
		x = 10;
		y = 20;
		System.out.println("It is a constructor without parameters");
	}
	
	public MultiCons(int x, int y)
	{
		this.x = x;
		this.y = y;
		System.out.println("It is a constructor with parameters");
	}
	
	public void PrintVal()
	{
		System.out.println("X value is : " + x);
		System.out.println("Y value is : " + y);
	}	
}

