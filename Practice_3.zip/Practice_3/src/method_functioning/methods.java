package method_functioning;
import java.util.*;

public class methods {
	public static void main(String args[]) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the number for factorial : ");
		int num1=sc.nextInt();
		System.out.println("enter the side of square : ");
		int s=sc.nextInt();
		System.out.println("enter the radius of cicle : ");
		float r=sc.nextFloat();
		methods object=new methods();
		System.out.println("factorial is : " + object.factorial(num1));
		System.out.println("Area of Square : " + object.area(s));
		System.out.println("Area of Circle : "+ object.area(r));

	
		
		}
	public  int factorial(int num1) {
		if (num1==1)
				return 1;
		return num1*factorial(num1-1);
	}
	
	//method overloading
	public int area(int s)
    {
         return s*s;
    }
    public float area(float r) 
    {
       return (float) (3.14*r*r);
    }

	


}
