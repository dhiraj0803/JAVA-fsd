package Maps;
import java.util.*;

public class maps {
	public static void main(String[] args) {
	    HashMap<String, String> names = new HashMap<String, String>();
	    names.put("Dhiraj", "Yadav");
	    names.put("Dhiraj", "Singh");
	    names.put("Ankur", "Maurya");
	    names.put("Armaan", "Ali");
	    System.out.println(names); 
	    
	    for(Map.Entry name:names.entrySet()) {
	    	System.out.println(name.getKey() + " " + name.getValue());
	    }
	  }
	

}
